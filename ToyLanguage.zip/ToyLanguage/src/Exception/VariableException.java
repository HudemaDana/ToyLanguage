package Exception;

public class VariableException extends Exception{
    public VariableException(String message){

        super(message);
    }
}
