package Exception;

public class FullCollectionException extends Exception{
    public FullCollectionException(String message){

        super(message);
    }
}
